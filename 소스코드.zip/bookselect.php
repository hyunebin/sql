<?php
   $con=mysqli_connect("localhost", "root", "1234", "kimDB") or die("MySQL 접속 실패 !!");

   $sql ="SELECT * FROM bookTbl";
 
   $ret = mysqli_query($con, $sql);   
   if($ret) {
	   $count = mysqli_num_rows($ret);
   }
   else {
	   echo "bookTbl 데이터 조회 실패!!!"."<br>";
	   echo "실패 원인 :".mysqli_error($con);
	   exit();
   } 
   
   echo "<h1> 도서 조회 결과 </h1>";
   echo "<TABLE border=1>";
   echo "<TR>";
   echo "<TH>책일련번호</TH><TH>도서이름</TH><TH>저자</TH><TH>가격</TH><TH>대출가능</TH>";
   echo "<TH>수정</TH><TH>삭제</TH>";
   echo "</TR>";
   
   while($row = mysqli_fetch_array($ret)) {
	  echo "<TR>";
	  echo "<TD>", $row['bookID'], "</TD>";
	  echo "<TD>", $row['bookname'], "</TD>";
	  echo "<TD>", $row['Author'], "</TD>";
	  echo "<TD>", $row['Price'], "</TD>";
	  echo "<TD>", $row['Loans'], "</TD>";
	  echo "<TD>", "<a href='update.php?userID=", $row['bookID'], "'>수정</a></TD>";
	  echo "<TD>", "<a href='delete.php?userID=", $row['bookID'], "'>삭제</a></TD>";
	  echo "</TR>";	  
   }   
   mysqli_close($con);
   echo "</TABLE>"; 
   echo "<br> <a href='main.html'> <--초기 화면</a> ";
?>
