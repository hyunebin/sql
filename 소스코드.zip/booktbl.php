<?php
   
   $con=mysqli_connect("localhost", "root", "1234", "kimDB") or die("MySQL 접속 실패 !!");

   $sql ="
	   CREATE TABLE bookTbl 
		( bookID  	CHAR(8) NOT NULL PRIMARY KEY,
		  bookname  CHAR(100) NOT NULL,
		  Author    CHAR(100) NOT NULL,
		  Price	  	CHAR(100) NOT NULL,
		  Loans		CHAR(100) 
		)
   ";
 
   $ret = mysqli_query($con, $sql);
 
   if($ret) {
	   echo "bookTbl이 성공적으로 생성됨..";
   }
   else {
	   echo "userTBL 생성 실패!!!"."<br>";
	   echo "실패 원인 :".mysqli_error($con);
   }
 
   mysqli_close($con);
?>
