<?php
   $con=mysqli_connect("localhost", "root", "1234", "kimDB") or die("MySQL 접속 실패 !!");
   $sql ="SELECT * FROM userTbl WHERE userID='".$_GET['userID']."'";

   $ret = mysqli_query($con, $sql);   
   if($ret) {
	   $count = mysqli_num_rows($ret);
	   if ($count==0) {
		   echo $_GET['userID']." 아이디의 회원이 없음!!!"."<br>";
		   echo "<br> <a href='main.html'> <--초기 화면</a> ";
		   exit();	
	   }		   
   }
   else {
	   echo "데이터 조회 실패!!!"."<br>";
	   echo "실패 원인 :".mysqli_error($con);
	   echo "<br> <a href='main.html'> <--초기 화면</a> ";
	   exit();
   }   
   $row = mysqli_fetch_array($ret);
   $userID = $row['userID'];
   $username = $row["username"];
   $age = $row["age"];
   $phoneNum = $row["phoneNum"];
   $Address = $row["Address"];   
?>

<HTML>
<HEAD>
<META http-equiv="content-type" content="text/html; charset=utf-8">
</HEAD>
<BODY>

<h1> 회원 정보 수정 </h1>
<FORM METHOD="post"  ACTION="userUpdate_result.php">
	아이디 : <INPUT TYPE ="text" NAME="userID" VALUE=<?php echo $userID ?> READONLY> <br>
	이름 : <INPUT TYPE ="text" NAME="username" VALUE=<?php echo $username ?>> <br> 
	출생년도 : <INPUT TYPE ="text" NAME="age" VALUE=<?php echo $age ?>> <br>
	휴대폰 전화번호 : <INPUT TYPE ="text" NAME="phoneNum" VALUE=<?php echo $phoneNum ?>> <br>
	지역 : <INPUT TYPE ="text" NAME="Address" VALUE=<?php echo $Address ?>> <br>
	<BR><BR>
	<INPUT TYPE="submit"  VALUE="정보 수정">
</FORM>

</BODY>
</HTML>