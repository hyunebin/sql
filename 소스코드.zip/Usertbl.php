<?php
   
   $con=mysqli_connect("localhost", "root", "1234", "kimDB") or die("MySQL 접속 실패 !!");

   $sql ="
	   CREATE TABLE userTbl 
		( userID  	CHAR(8) NOT NULL PRIMARY KEY,
		  username  CHAR(20) NOT NULL,
		  age       CHAR(10) NOT NULL,
		  phoneNum	CHAR(20) NOT NULL,
		  Address	CHAR(20) 
		)
   ";
 
   $ret = mysqli_query($con, $sql);
 
   if($ret) {
	   echo "userTbl이 성공적으로 생성됨..";
   }
   else {
	   echo "userTBL 생성 실패!!!"."<br>";
	   echo "실패 원인 :".mysqli_error($con);
   }
 
   mysqli_close($con);
?>
