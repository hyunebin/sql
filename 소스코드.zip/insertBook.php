<?php
   $con=mysqli_connect('localhost', 'root', '1234', 'kimDB') or die('MySQL 접속 실패 !!');

   $sql ="
		INSERT INTO booktbl VALUES
        ('1', '신의카르테1', '소스케나츠카와', '12800', '1')

   ";
 
   $ret = mysqli_query($con, $sql);
 
   if($ret) {
	   echo "bookTbl이 데이터가 성공적으로 입력됨.";
   }
   else {
	   echo "실패 원인 :".mysqli_error($con);
   }
 
   mysqli_close($con);
?>