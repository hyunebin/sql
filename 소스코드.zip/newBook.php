<HTML>
<HEAD>
<META http-equiv="content-type" content="text/html; charset=utf-8">
</HEAD>
<BODY>

<h1> 입고 </h1>
<FORM METHOD="post"  ACTION="newBook_result.php">
	아이디 : <INPUT TYPE ="text" NAME="bookID"> <br>
	책이름 : <INPUT TYPE ="text" NAME="bookname"> <br> 
	저자 : <INPUT TYPE ="text" NAME="Author"> <br>
	가격 : <INPUT TYPE ="text" NAME="Price"> <br>
    대출가능 : <INPUT TYPE ="text" NAME="Loans"> <br>
	<BR><BR>
	<INPUT TYPE="submit"  VALUE="회원 입력">
</FORM>

</BODY>
</HTML>