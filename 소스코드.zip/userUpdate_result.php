<?php
   $con=mysqli_connect("localhost", "root", "1234", "kimDB") or die("MySQL 접속 실패 !!");

   $userID = $_POST["userID"];
   $username = $_POST["username"];
   $age = $_POST["age"];
   $phoneNum = $_POST["phoneNum"];
   $Address = $_POST["Address"];
 
   $sql = "UPDATE userTbl SET name='".$username."','".$age."','".$phoneNum."','".$Address."'WHERE userID='".$userID."'";


   
   $ret = mysqli_query($con, $sql);
 
    echo "<h1> 회원 정보 수정 결과 </h1>";
   if($ret) {
	   echo "데이터가 성공적으로 수정됨.";
   }
   else {
	   echo "데이터 수정 실패!!!"."<br>";
	   echo "실패 원인 :".mysqli_error($con);
   } 
   mysqli_close($con);
   
   echo "<br> <a href='main.html'> <--초기 화면</a> ";
?>